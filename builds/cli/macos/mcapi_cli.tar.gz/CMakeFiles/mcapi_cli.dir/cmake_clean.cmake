file(REMOVE_RECURSE
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_assets.cpp.o"
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_assets.cpp.o.d"
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o"
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o.d"
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o"
  "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o.d"
  "CMakeFiles/mcapi_cli.dir/cli.cpp.o"
  "CMakeFiles/mcapi_cli.dir/cli.cpp.o.d"
  "mcapi_cli"
  "mcapi_cli.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/mcapi_cli.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
