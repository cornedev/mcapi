# Empty compiler generated dependencies file for mcapi_cli.
# This may be replaced when dependencies are built.
