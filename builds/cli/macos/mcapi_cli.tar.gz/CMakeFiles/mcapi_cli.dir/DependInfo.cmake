
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/runner/work/mcapi/mcapi/api/mcapi_assets.cpp" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_assets.cpp.o" "gcc" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_assets.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/mcapi_java.cpp" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o" "gcc" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/mcapi_process.cpp" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o" "gcc" "CMakeFiles/mcapi_cli.dir/Users/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/cli/cli.cpp" "CMakeFiles/mcapi_cli.dir/cli.cpp.o" "gcc" "CMakeFiles/mcapi_cli.dir/cli.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
