/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui
{
public:
    QStackedWidget *pages;
    QWidget *login;
    QPushButton *continuebutton;
    QLabel *logologin;
    QLabel *label;
    QWidget *launcher;
    QLabel *version;
    QLabel *username;
    QLineEdit *usernameinput;
    QComboBox *versionbox;
    QLabel *os;
    QComboBox *osbox;
    QLabel *arch;
    QComboBox *archbox;
    QCheckBox *schoolcheckbox;
    QPushButton *startbutton;
    QPushButton *stopbutton;
    QLabel *console;
    QPlainTextEdit *consolelog;
    QLabel *logo;

    void setupUi(QWidget *gui)
    {
        if (gui->objectName().isEmpty())
            gui->setObjectName("gui");
        gui->resize(400, 676);
        gui->setMinimumSize(QSize(400, 676));
        gui->setMaximumSize(QSize(400, 676));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/gfx/mcapi_gui.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        gui->setWindowIcon(icon);
        pages = new QStackedWidget(gui);
        pages->setObjectName("pages");
        pages->setGeometry(QRect(0, 0, 400, 676));
        login = new QWidget();
        login->setObjectName("login");
        continuebutton = new QPushButton(login);
        continuebutton->setObjectName("continuebutton");
        continuebutton->setGeometry(QRect(140, 90, 111, 51));
        logologin = new QLabel(login);
        logologin->setObjectName("logologin");
        logologin->setGeometry(QRect(131, 30, 131, 41));
        logologin->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_logo.png")));
        label = new QLabel(login);
        label->setObjectName("label");
        label->setGeometry(QRect(155, 160, 81, 16));
        pages->addWidget(login);
        launcher = new QWidget();
        launcher->setObjectName("launcher");
        version = new QLabel(launcher);
        version->setObjectName("version");
        version->setGeometry(QRect(175, 150, 81, 16));
        username = new QLabel(launcher);
        username->setObjectName("username");
        username->setGeometry(QRect(167, 90, 61, 16));
        usernameinput = new QLineEdit(launcher);
        usernameinput->setObjectName("usernameinput");
        usernameinput->setGeometry(QRect(120, 110, 151, 24));
        usernameinput->setClearButtonEnabled(false);
        versionbox = new QComboBox(launcher);
        versionbox->setObjectName("versionbox");
        versionbox->setGeometry(QRect(120, 170, 151, 24));
        versionbox->setEditable(false);
        versionbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        os = new QLabel(launcher);
        os->setObjectName("os");
        os->setGeometry(QRect(187, 210, 81, 16));
        osbox = new QComboBox(launcher);
        osbox->setObjectName("osbox");
        osbox->setGeometry(QRect(120, 230, 151, 24));
        arch = new QLabel(launcher);
        arch->setObjectName("arch");
        arch->setGeometry(QRect(183, 270, 81, 16));
        archbox = new QComboBox(launcher);
        archbox->setObjectName("archbox");
        archbox->setGeometry(QRect(120, 290, 151, 24));
        schoolcheckbox = new QCheckBox(launcher);
        schoolcheckbox->setObjectName("schoolcheckbox");
        schoolcheckbox->setGeometry(QRect(143, 340, 101, 21));
        schoolcheckbox->setChecked(true);
        startbutton = new QPushButton(launcher);
        startbutton->setObjectName("startbutton");
        startbutton->setGeometry(QRect(100, 370, 191, 41));
        stopbutton = new QPushButton(launcher);
        stopbutton->setObjectName("stopbutton");
        stopbutton->setGeometry(QRect(100, 430, 191, 41));
        console = new QLabel(launcher);
        console->setObjectName("console");
        console->setGeometry(QRect(174, 480, 81, 16));
        consolelog = new QPlainTextEdit(launcher);
        consolelog->setObjectName("consolelog");
        consolelog->setGeometry(QRect(20, 500, 361, 151));
        logo = new QLabel(launcher);
        logo->setObjectName("logo");
        logo->setGeometry(QRect(131, 30, 131, 41));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_logo.png")));
        pages->addWidget(launcher);

        retranslateUi(gui);

        pages->setCurrentIndex(0);
        versionbox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(gui);
    } // setupUi

    void retranslateUi(QWidget *gui)
    {
        gui->setWindowTitle(QCoreApplication::translate("gui", "gui", nullptr));
        continuebutton->setText(QCoreApplication::translate("gui", "continue", nullptr));
        logologin->setText(QString());
        label->setText(QCoreApplication::translate("gui", "login page WIP", nullptr));
        version->setText(QCoreApplication::translate("gui", "Version  ", nullptr));
        username->setText(QCoreApplication::translate("gui", "Username", nullptr));
        os->setText(QCoreApplication::translate("gui", "OS", nullptr));
        arch->setText(QCoreApplication::translate("gui", "Arch", nullptr));
        schoolcheckbox->setText(QCoreApplication::translate("gui", "School fallback", nullptr));
        startbutton->setText(QCoreApplication::translate("gui", "Start", nullptr));
        stopbutton->setText(QCoreApplication::translate("gui", "Stop", nullptr));
        console->setText(QCoreApplication::translate("gui", "Console", nullptr));
        logo->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class gui: public Ui_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
