/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 6.10.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui
{
public:
    QPushButton *startbutton;
    QLabel *username;
    QLabel *version;
    QComboBox *versionbox;
    QLineEdit *usernameinput;
    QLabel *os;
    QComboBox *osbox;
    QLabel *arch;
    QComboBox *archbox;
    QLabel *logo;
    QPushButton *stopbutton;
    QPlainTextEdit *consolelog;
    QLabel *console;
    QCheckBox *schoolcheckbox;

    void setupUi(QWidget *gui)
    {
        if (gui->objectName().isEmpty())
            gui->setObjectName("gui");
        gui->resize(400, 676);
        gui->setMinimumSize(QSize(400, 400));
        gui->setMaximumSize(QSize(400, 800));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/gfx/mcapi_gui.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        gui->setWindowIcon(icon);
        startbutton = new QPushButton(gui);
        startbutton->setObjectName("startbutton");
        startbutton->setGeometry(QRect(100, 370, 191, 41));
        username = new QLabel(gui);
        username->setObjectName("username");
        username->setGeometry(QRect(167, 90, 61, 16));
        version = new QLabel(gui);
        version->setObjectName("version");
        version->setGeometry(QRect(175, 150, 81, 16));
        versionbox = new QComboBox(gui);
        versionbox->setObjectName("versionbox");
        versionbox->setGeometry(QRect(120, 170, 151, 24));
        versionbox->setEditable(false);
        versionbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        usernameinput = new QLineEdit(gui);
        usernameinput->setObjectName("usernameinput");
        usernameinput->setGeometry(QRect(120, 110, 151, 24));
        usernameinput->setClearButtonEnabled(false);
        os = new QLabel(gui);
        os->setObjectName("os");
        os->setGeometry(QRect(187, 210, 81, 16));
        osbox = new QComboBox(gui);
        osbox->setObjectName("osbox");
        osbox->setGeometry(QRect(120, 230, 151, 24));
        arch = new QLabel(gui);
        arch->setObjectName("arch");
        arch->setGeometry(QRect(183, 270, 81, 16));
        archbox = new QComboBox(gui);
        archbox->setObjectName("archbox");
        archbox->setGeometry(QRect(120, 290, 151, 24));
        logo = new QLabel(gui);
        logo->setObjectName("logo");
        logo->setGeometry(QRect(131, 30, 131, 41));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_logo.png")));
        stopbutton = new QPushButton(gui);
        stopbutton->setObjectName("stopbutton");
        stopbutton->setGeometry(QRect(100, 430, 191, 41));
        consolelog = new QPlainTextEdit(gui);
        consolelog->setObjectName("consolelog");
        consolelog->setGeometry(QRect(20, 500, 361, 151));
        console = new QLabel(gui);
        console->setObjectName("console");
        console->setGeometry(QRect(174, 480, 81, 16));
        schoolcheckbox = new QCheckBox(gui);
        schoolcheckbox->setObjectName("schoolcheckbox");
        schoolcheckbox->setGeometry(QRect(143, 340, 101, 21));
        schoolcheckbox->setChecked(true);

        retranslateUi(gui);

        versionbox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(gui);
    } // setupUi

    void retranslateUi(QWidget *gui)
    {
        gui->setWindowTitle(QCoreApplication::translate("gui", "gui", nullptr));
        startbutton->setText(QCoreApplication::translate("gui", "Start", nullptr));
        username->setText(QCoreApplication::translate("gui", "Username", nullptr));
        version->setText(QCoreApplication::translate("gui", "Version  ", nullptr));
        os->setText(QCoreApplication::translate("gui", "OS", nullptr));
        arch->setText(QCoreApplication::translate("gui", "Arch", nullptr));
        logo->setText(QString());
        stopbutton->setText(QCoreApplication::translate("gui", "Stop", nullptr));
        console->setText(QCoreApplication::translate("gui", "Console", nullptr));
        schoolcheckbox->setText(QCoreApplication::translate("gui", "School fallback", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui: public Ui_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
