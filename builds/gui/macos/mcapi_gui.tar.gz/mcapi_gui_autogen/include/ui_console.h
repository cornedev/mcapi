/********************************************************************************
** Form generated from reading UI file 'console.ui'
**
** Created by: Qt User Interface Compiler version 6.11.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONSOLE_H
#define UI_CONSOLE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_console
{
public:
    QPlainTextEdit *consolelog;
    QPushButton *closebutton;
    QLabel *consolelabel;

    void setupUi(QWidget *console)
    {
        if (console->objectName().isEmpty())
            console->setObjectName("console");
        console->resize(450, 287);
        consolelog = new QPlainTextEdit(console);
        consolelog->setObjectName("consolelog");
        consolelog->setGeometry(QRect(20, 30, 410, 191));
        closebutton = new QPushButton(console);
        closebutton->setObjectName("closebutton");
        closebutton->setGeometry(QRect(170, 230, 110, 41));
        consolelabel = new QLabel(console);
        consolelabel->setObjectName("consolelabel");
        consolelabel->setGeometry(QRect(200, 10, 51, 16));

        retranslateUi(console);

        QMetaObject::connectSlotsByName(console);
    } // setupUi

    void retranslateUi(QWidget *console)
    {
        console->setWindowTitle(QCoreApplication::translate("console", "console", nullptr));
        closebutton->setText(QCoreApplication::translate("console", "Close", nullptr));
        consolelabel->setText(QCoreApplication::translate("console", "Console", nullptr));
    } // retranslateUi

};

namespace Ui {
    class console: public Ui_console {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONSOLE_H
