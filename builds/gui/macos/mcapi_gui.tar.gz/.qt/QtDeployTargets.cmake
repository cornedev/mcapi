set(__QT_DEPLOY_TARGET_mcapi_gui_FILE /Users/runner/work/mcapi/mcapi/gui/build/mcapi_gui.app/Contents/MacOS/mcapi_gui)
set(__QT_DEPLOY_TARGET_mcapi_gui_TYPE EXECUTABLE)
