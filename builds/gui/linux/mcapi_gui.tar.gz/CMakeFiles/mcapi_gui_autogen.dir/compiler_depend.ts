# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for mcapi_gui_autogen.
