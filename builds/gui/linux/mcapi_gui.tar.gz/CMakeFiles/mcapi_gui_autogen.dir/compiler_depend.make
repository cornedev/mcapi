# Empty custom commands generated dependencies file for mcapi_gui_autogen.
# This may be replaced when dependencies are built.
