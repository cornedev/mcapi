file(REMOVE_RECURSE
  "CMakeFiles/mcapi_gui_autogen"
  "mcapi_gui_autogen/include/ui_gui.h"
  "mcapi_gui_autogen/mocs_compilation.cpp"
  "mcapi_gui_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcapi_gui_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
