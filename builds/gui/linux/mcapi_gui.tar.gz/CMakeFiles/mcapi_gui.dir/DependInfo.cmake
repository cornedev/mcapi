
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/runner/work/mcapi/mcapi/gui/console.cpp" "CMakeFiles/mcapi_gui.dir/console.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/console.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/gui/gui.cpp" "CMakeFiles/mcapi_gui.dir/gui.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/gui.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/api/mcapi_fabric.cpp" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_fabric.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_fabric.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/api/mcapi_java.cpp" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/api/mcapi_process.cpp" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/api/mcapi_vanilla.cpp" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_vanilla.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_vanilla.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/gui/main.cpp" "CMakeFiles/mcapi_gui.dir/main.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/main.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/gui/build/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp" "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp.o.d"
  "/home/runner/work/mcapi/mcapi/gui/build/mcapi_gui_autogen/mocs_compilation.cpp" "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/mocs_compilation.cpp.o" "gcc" "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/mocs_compilation.cpp.o.d"
  "" "mcapi_gui" "gcc" "CMakeFiles/mcapi_gui.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
