CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp.o: \
 /home/runner/work/mcapi/mcapi/gui/build/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp \
 /usr/include/stdc-predef.h
