file(REMOVE_RECURSE
  "CMakeFiles/mcapi_gui.dir/link.d"
  "CMakeFiles/mcapi_gui_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/mcapi_gui_autogen.dir/ParseCache.txt"
  "mcapi_gui_autogen"
  "CMakeFiles/mcapi_gui.dir/console.cpp.o"
  "CMakeFiles/mcapi_gui.dir/console.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/gui.cpp.o"
  "CMakeFiles/mcapi_gui.dir/gui.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_auth.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_auth.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_fabric.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_fabric.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_http.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_http.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_java.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_process.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_vanilla.cpp.o"
  "CMakeFiles/mcapi_gui.dir/home/runner/work/mcapi/mcapi/api/mcapi_vanilla.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/main.cpp.o"
  "CMakeFiles/mcapi_gui.dir/main.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp.o"
  "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp.o.d"
  "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/mocs_compilation.cpp.o"
  "CMakeFiles/mcapi_gui.dir/mcapi_gui_autogen/mocs_compilation.cpp.o.d"
  "mcapi_gui"
  "mcapi_gui.pdb"
  "mcapi_gui_autogen/EWIEGA46WW/qrc_resources.cpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/mcapi_gui.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
