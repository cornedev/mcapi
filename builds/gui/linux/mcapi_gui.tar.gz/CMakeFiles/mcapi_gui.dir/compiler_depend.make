# Empty compiler generated dependencies file for mcapi_gui.
# This may be replaced when dependencies are built.
