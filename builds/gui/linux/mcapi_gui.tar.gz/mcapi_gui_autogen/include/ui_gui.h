/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui
{
public:
    QStackedWidget *pages;
    QWidget *login;
    QPushButton *offlinebutton;
    QLabel *logologin;
    QLabel *label;
    QLabel *loginbackground;
    QPushButton *loginmicrosoftbutton;
    QWidget *launcher;
    QLabel *version;
    QLabel *username;
    QLineEdit *usernameinput;
    QComboBox *versionbox;
    QLabel *os;
    QComboBox *osbox;
    QLabel *arch;
    QComboBox *archbox;
    QCheckBox *schoolcheckbox;
    QPushButton *startbutton;
    QPushButton *stopbutton;
    QLabel *logo;
    QLabel *launcherbackground;
    QComboBox *loaderbox;
    QLabel *loader;
    QPushButton *consolebutton;

    void setupUi(QWidget *gui)
    {
        if (gui->objectName().isEmpty())
            gui->setObjectName("gui");
        gui->resize(725, 676);
        gui->setMinimumSize(QSize(725, 676));
        gui->setMaximumSize(QSize(725, 676));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/gfx/mcapi_gui.png"), QSize(), QIcon::Normal, QIcon::Off);
        gui->setWindowIcon(icon);
        pages = new QStackedWidget(gui);
        pages->setObjectName("pages");
        pages->setGeometry(QRect(0, 0, 725, 676));
        pages->setMinimumSize(QSize(725, 676));
        pages->setMaximumSize(QSize(725, 676));
        login = new QWidget();
        login->setObjectName("login");
        offlinebutton = new QPushButton(login);
        offlinebutton->setObjectName("offlinebutton");
        offlinebutton->setGeometry(QRect(495, 110, 111, 51));
        logologin = new QLabel(login);
        logologin->setObjectName("logologin");
        logologin->setGeometry(QRect(486, 30, 131, 41));
        logologin->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_logo.png")));
        label = new QLabel(login);
        label->setObjectName("label");
        label->setGeometry(QRect(515, 640, 91, 16));
        loginbackground = new QLabel(login);
        loginbackground->setObjectName("loginbackground");
        loginbackground->setGeometry(QRect(0, 0, 725, 676));
        loginbackground->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_background_login.png")));
        loginmicrosoftbutton = new QPushButton(login);
        loginmicrosoftbutton->setObjectName("loginmicrosoftbutton");
        loginmicrosoftbutton->setEnabled(false);
        loginmicrosoftbutton->setGeometry(QRect(495, 180, 111, 51));
        pages->addWidget(login);
        loginbackground->raise();
        offlinebutton->raise();
        logologin->raise();
        label->raise();
        loginmicrosoftbutton->raise();
        launcher = new QWidget();
        launcher->setObjectName("launcher");
        version = new QLabel(launcher);
        version->setObjectName("version");
        version->setGeometry(QRect(155, 200, 81, 16));
        username = new QLabel(launcher);
        username->setObjectName("username");
        username->setGeometry(QRect(147, 90, 61, 16));
        usernameinput = new QLineEdit(launcher);
        usernameinput->setObjectName("usernameinput");
        usernameinput->setGeometry(QRect(100, 110, 151, 24));
        usernameinput->setClearButtonEnabled(false);
        versionbox = new QComboBox(launcher);
        versionbox->setObjectName("versionbox");
        versionbox->setGeometry(QRect(100, 220, 151, 24));
        versionbox->setEditable(false);
        versionbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        os = new QLabel(launcher);
        os->setObjectName("os");
        os->setGeometry(QRect(167, 260, 81, 16));
        osbox = new QComboBox(launcher);
        osbox->setObjectName("osbox");
        osbox->setGeometry(QRect(100, 280, 151, 24));
        arch = new QLabel(launcher);
        arch->setObjectName("arch");
        arch->setGeometry(QRect(163, 320, 81, 16));
        archbox = new QComboBox(launcher);
        archbox->setObjectName("archbox");
        archbox->setGeometry(QRect(100, 340, 151, 24));
        schoolcheckbox = new QCheckBox(launcher);
        schoolcheckbox->setObjectName("schoolcheckbox");
        schoolcheckbox->setGeometry(QRect(123, 390, 101, 21));
        schoolcheckbox->setChecked(true);
        startbutton = new QPushButton(launcher);
        startbutton->setObjectName("startbutton");
        startbutton->setGeometry(QRect(80, 420, 191, 41));
        stopbutton = new QPushButton(launcher);
        stopbutton->setObjectName("stopbutton");
        stopbutton->setGeometry(QRect(80, 480, 191, 41));
        logo = new QLabel(launcher);
        logo->setObjectName("logo");
        logo->setGeometry(QRect(110, 30, 131, 41));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_logo.png")));
        launcherbackground = new QLabel(launcher);
        launcherbackground->setObjectName("launcherbackground");
        launcherbackground->setGeometry(QRect(0, 0, 725, 676));
        launcherbackground->setPixmap(QPixmap(QString::fromUtf8(":/gfx/mcapi_background_launcher.png")));
        loaderbox = new QComboBox(launcher);
        loaderbox->setObjectName("loaderbox");
        loaderbox->setGeometry(QRect(100, 160, 151, 24));
        loaderbox->setEditable(false);
        loaderbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        loader = new QLabel(launcher);
        loader->setObjectName("loader");
        loader->setGeometry(QRect(156, 140, 81, 16));
        consolebutton = new QPushButton(launcher);
        consolebutton->setObjectName("consolebutton");
        consolebutton->setGeometry(QRect(80, 540, 191, 41));
        pages->addWidget(launcher);
        launcherbackground->raise();
        version->raise();
        username->raise();
        usernameinput->raise();
        versionbox->raise();
        os->raise();
        osbox->raise();
        arch->raise();
        archbox->raise();
        schoolcheckbox->raise();
        startbutton->raise();
        stopbutton->raise();
        logo->raise();
        loaderbox->raise();
        loader->raise();
        consolebutton->raise();

        retranslateUi(gui);

        pages->setCurrentIndex(1);
        versionbox->setCurrentIndex(-1);
        loaderbox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(gui);
    } // setupUi

    void retranslateUi(QWidget *gui)
    {
        gui->setWindowTitle(QCoreApplication::translate("gui", "mcapi launcher", nullptr));
        offlinebutton->setText(QCoreApplication::translate("gui", "Play offline", nullptr));
        logologin->setText(QString());
        label->setText(QCoreApplication::translate("gui", "login page WIP.", nullptr));
        loginbackground->setText(QString());
        loginmicrosoftbutton->setText(QCoreApplication::translate("gui", "Microsoft login", nullptr));
        version->setText(QCoreApplication::translate("gui", "Version  ", nullptr));
        username->setText(QCoreApplication::translate("gui", "Username", nullptr));
        os->setText(QCoreApplication::translate("gui", "OS", nullptr));
        arch->setText(QCoreApplication::translate("gui", "Arch", nullptr));
        schoolcheckbox->setText(QCoreApplication::translate("gui", "School fallback", nullptr));
        startbutton->setText(QCoreApplication::translate("gui", "Start", nullptr));
        stopbutton->setText(QCoreApplication::translate("gui", "Stop", nullptr));
        logo->setText(QString());
        launcherbackground->setText(QString());
        loader->setText(QCoreApplication::translate("gui", "Loader  ", nullptr));
        consolebutton->setText(QCoreApplication::translate("gui", "Console", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui: public Ui_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
